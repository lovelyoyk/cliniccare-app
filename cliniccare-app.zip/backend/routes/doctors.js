const express = require('express');
const { getDoctors } = require('../controllers/doctorController');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/', auth, getDoctors);

module.exports = router;