const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema({
    date: String,
    time: String,
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});

module.exports = mongoose.model('Appointment', appointmentSchema);