const Appointment = require('../models/Appointment');

exports.createAppointment = async (req, res) => {
    try {
        const appointment = await Appointment.create({ ...req.body, patient: req.user.id });
        res.json(appointment);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAppointments = async (req, res) => {
    try {
        const appointments = await Appointment.find().populate('doctor').populate('patient');
        res.json(appointments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};