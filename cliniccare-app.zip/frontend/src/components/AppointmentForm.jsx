import React, { useState, useEffect } from 'react';
import axios from '../api';

function AppointmentForm() {
  const [doctors, setDoctors] = useState([]);
  const [form, setForm] = useState({ date: '', time: '', doctor: '' });

  useEffect(() => {
    async function fetchDoctors() {
      const res = await axios.get('/doctors');
      setDoctors(res.data);
    }
    fetchDoctors();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/appointments', form);
    alert('Appointment created!');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Date" onChange={(e) => setForm({ ...form, date: e.target.value })} />
      <input placeholder="Time" onChange={(e) => setForm({ ...form, time: e.target.value })} />
      <select onChange={(e) => setForm({ ...form, doctor: e.target.value })}>
        {doctors.map(doc => <option key={doc._id} value={doc._id}>{doc.name}</option>)}
      </select>
      <button type="submit">Book</button>
    </form>
  );
}

export default AppointmentForm;