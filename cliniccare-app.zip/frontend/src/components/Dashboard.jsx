import React, { useState, useEffect } from 'react';
import axios from '../api';

function Dashboard() {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    async function fetchAppointments() {
      const res = await axios.get('/appointments');
      setAppointments(res.data);
    }
    fetchAppointments();
  }, []);

  return (
    <div>
      <h1>Appointments</h1>
      {appointments.map(app => (
        <div key={app._id}>
          {app.date} - {app.time} with Dr. {app.doctor.name}
        </div>
      ))}
    </div>
  );
}

export default Dashboard;