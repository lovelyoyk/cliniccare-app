# ClinicCare App

Aplicativo para gerenciamento de consultas médicas.

## Como rodar

### Backend
```bash
cd backend
npm install
npm run start
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```